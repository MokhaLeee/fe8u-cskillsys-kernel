#include "common-chax.h"
#include "kernel-lib.h"

void KernelPad1(void) {}

int KernelPad2(int val)
{
	return val;
}

bool KernelPad3(void)
{
	return true;
}

bool KernelPad4(void)
{
	return false;
}
