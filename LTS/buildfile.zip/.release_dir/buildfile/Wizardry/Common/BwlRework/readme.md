# BWL rewrok

1. Remove vanilla BWL table except Battle/Win/Loss.
2. Move unit support data to BWL table
