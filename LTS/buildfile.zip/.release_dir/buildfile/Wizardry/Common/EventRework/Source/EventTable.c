#include "common-chax.h"

const EventFuncType gEventLoCmdTableRe[0x80] = {
	_EventLoCmds
};
