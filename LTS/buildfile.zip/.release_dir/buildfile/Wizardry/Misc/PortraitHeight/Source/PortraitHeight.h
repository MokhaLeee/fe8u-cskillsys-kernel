#pragma once

#include <common-chax.h>

extern const u8 HighPortraitFidLut[];
extern const u8 *gpHighPortraitFidLut;
