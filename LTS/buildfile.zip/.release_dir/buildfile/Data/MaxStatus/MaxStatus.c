#include <common-chax.h>
#include <status-getter.h>

const struct UnitMaxStatusConfig gUnitMaxStatusConfigTable[0x100] = {};
