#pragma once

enum ai_conf_expa {
	AI_UNIT_CONFIG_EXTFLAG_TELEPORTATION = 1 << 8,
};
